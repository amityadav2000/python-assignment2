str=input("enter the string")

print(str)

ch=input("enter character which occurence is to be find")

print(ch)

occr=str.count(ch)
print(occr)

