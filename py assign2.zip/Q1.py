a=[1,2,3,"hii",[],"hello"]
print(a)

b=list(filter(lambda x:x!=[ ],a))

print(b)
