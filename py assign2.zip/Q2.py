str=input("enter a sentence")
print(str)

str=str.split()
print(str)

str2=[]
for i in str:
	if i  not in str2:
		str2.append(i)
		str2.append("")

str=" " 
for j in str2:
	
			
					str=str+j
					str=str+" "	
print(str)
	